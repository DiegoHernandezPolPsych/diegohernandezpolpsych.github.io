# Site Template

A single-page academic/personal site: sticky tabbed nav (About, Research,
Teaching, CV, Contact), light/dark theme with a smooth circular
transition, and a Vienna Secession–inspired visual language (Fraunces +
Hanken Grotesk + Spline Sans Mono, geometric triad mark, hairline
rules). No build step, no framework — plain HTML, CSS, and JavaScript
in one file. Free to use and adapt for your own site.

## Quick start

1. Unzip this somewhere.
2. Open `index.html` directly in a browser to preview it — everything
   works from a local file, no server needed.
3. Search the file for `EDIT` comments (`Cmd/Ctrl+F` → "EDIT") and work
   through them top to bottom: name, role, bio, links, research/teaching
   cards, CV entries, contact details.
4. Replace the placeholder text (`[Your Title]`, `[Institution]`, etc.)
   with your own.
5. Add a favicon of your own and link it in `<head>` (see "Favicon" below).
6. Push it to a GitHub repo and turn on GitHub Pages (Settings → Pages →
   Deploy from branch), or host it anywhere that serves static files.

## What's in here

```
index.html   the site — structure, styles, and behavior in one file
images/      put your own images here (see below)
files/       put your own PDF(s) here (see below)
```

## Favicon

Not included, since the original used a personal mark. Add your own
icon file and link it near the top of `<head>` — there's a commented
example line showing the expected format (search for "favicon" in the
file).

## Images to add

None are required — the site works with none of them, it just looks
plainer. Add the ones you want at these exact paths:

| Path | Used for | Notes |
| --- | --- | --- |
| `images/profile.jpg` | Portrait on the About tab | 4:5 aspect ratio works best. After adding it, uncomment the `<img>` line right above the placeholder `<span>` in the About section (search for `profile.jpg`). |
| `images/about-bg.jpg` | Full-bleed art behind the About tab | Optional. Without it, the About tab just shows the plain background color. |
| `images/gold-flood.jpg` | A hidden gold-flood animation, currently disabled in the JS (search `GILT` in the `<script>` at the bottom) | Optional easter egg — safe to ignore. |

The About-tab background actually supports **cycling through multiple
paintings** (a different one each visit) via a `paintings` array — that
feature reads from a CMS content file this template doesn't include, so
by default it's inactive and the tab just shows your `about-bg.jpg` (or
nothing, if you skip it). Not worth wiring up unless you specifically
want a rotating background.

## Files to add

| Path | Used for |
| --- | --- |
| `files/cv.pdf` | The "Download CV (PDF)" and "Curriculum Vitae" links |

## SEO / metadata

The `<head>` includes Open Graph tags, Twitter card tags, a JSON-LD
`Person` schema, and Highwire Press `citation_*` tags (the last of
these help Google Scholar index a paper — useful if you're on the
academic job market, safe to delete if not). All of it is placeholder
text — fill it in, or delete blocks you don't want. You'll also want to
generate your own `og-image.png` (1200×630) for social share cards and
point `og:image`/`twitter:image` at it.

## Fonts

Loaded from Google Fonts via `<link>` tags already in `<head>` —
Fraunces, Hanken Grotesk, Spline Sans Mono. No local font files to
manage. Swap the `<link href="https://fonts.googleapis.com/...">` line
and the `--font-display` / `--font-body` / `--font-mono` variables near
the top of the `<style>` block if you want different typefaces.

## Colors

All colors are CSS custom properties in `oklch()`, defined twice (once
for `[data-theme="light"]`, once for `[data-theme="dark"]`) near the top
of the `<style>` block. Change the values there to retheme the whole
site — everything else references these variables, nothing is
hard-coded elsewhere.

## Credit

The colophon at the bottom of the page (the small "Set in Fraunces and
Hanken Grotesk…" line) credits this template's origin. Keep, edit, or
remove it — your call.
